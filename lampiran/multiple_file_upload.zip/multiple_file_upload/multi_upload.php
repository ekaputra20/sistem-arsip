<html>
    <head>
    </head>
    <title> Dynamic Image Uploading :: Automatic Create File Uploading Field</title>
    <head>
    <script type="text/javascript" src="js/jquery-1.4.2.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.8.custom.min.js"></script>
    <script type="text/javascript">

    $(function(){
        
        $("a:[id=createNew]").bind("click",function(){

                var CounterLimit = 10;
                var LastDivId = $("div:[id=FileUploadDiv]:last").attr("DivValue");
                var appandingDiv = $("div:[id=FileUploadDiv][DivValue="+LastDivId+"]");
                var NewDivId = eval(LastDivId)+1;
                if(CounterLimit>NewDivId){
                var NewUploadDiv = "<div align='left' id='FileUploadDiv' DivValue='"+NewDivId+"' style='display: none'>"+
                        "<input name='filename"+NewDivId+"' type='file' id='filename'>"+
                    "</div>";
                var UploadDivCounter =eval($("#counter").val())+1;
                $("#counter").val(UploadDivCounter);
                $(NewUploadDiv).show().clone().appendTo(appandingDiv);

            }
            else
            {
                var AlertMessage= "You Can upload maximum "+CounterLimit+" Files!";
                alert(AlertMessage);
            }
        return false;
        });

    });
    </script>
    <style type="text/css">
        div#upload_box_wrapper{width:300px;text-align:center;border:3px solid lightblue;float: left;font-family: verdana; font-size: 12px;padding: 5px 5px 5px 5px;background:url(./images/background.jpg) no-repeat; color: white;}
        div#upload_box_wrapper #upload_title_text{text-align:left;width: 100%;display: block;border: 0px solid green; margin-bottom: 5px;}
        div#upload_box_wrapper #FileUploadDiv{display: block;width: 98%;border: 0px solid green; text-align: left;padding: 0px 0px 0px 0px;}
        div#upload_box_wrapper p.add-new-upload-box{float: left;width: 100%;text-align: right;}
        div#upload_box_wrapper a.add-new-upload-link{font-weight: bold;font-size: 13px;padding-right: 3px;text-decoration: none; color: yellow;}
        div#upload_box_wrapper .upload-button{border: 0px solid lightgreen;height:30px; width:120px;cursor: pointer;background:url(./images/upload_button.png) no-repeat center left; color: white;}

        
    </style>
    </head>

    <body>

<form method='post' action='multi_upload_now.php' enctype='multipart/form-data'>
        <div id="upload_box_wrapper">

                <div id="upload_title_text">Upload Image:</div>
                    <div id="FileUploadDiv" DivValue="0">
                        <input name='filename0' type='file' id='filename'>
                    </div>

                    <p class="add-new-upload-box">
                        <a href="#" id="createNew" class="add-new-upload-link">Add More </a>
                    </p>
                    <input type="hidden" value="0" id="counter" name="counter">

                    <div align='left'>
                        Upload Image:&nbsp;<input type='submit' name='submit' value='Upload Now!' class="upload-button">
                    </div>

    </div>
</form>
    <style type="text/css">
        div.upload-feature-container{float: left;width: 100%;font-family: verdana;font-size: 13px;font-weight: bold;}
        ul.upload-feature{font-family: verdana;font-size: 12px;font-weight: normal;}
        ul.upload-feature li{font-size: 12px; list-style: none;padding-bottom: 5px;}
    </style>
        <div class="upload-feature-container">
        Uploader Features:
        <ul class="upload-feature">
            <li>1. Upload multiple files.</li>
            <li>2. Checking file types and extension. </li>
            <li>3. Create upload fileds dynamically.</li>
            <li>4. Upload and instant preview of your uploaded images.</li>
            <li>5. CodeIgniter Module Available .</li>
            <li>6. User friendly, easy to setup and customize.
            <li>6. Tested in popular browsers like Mozilla Firefox, Chrome, Internet Explorer.</li>
            <li>7. Source code is free to download.</li>
        </ul>
        </div>
        
</body>
</html>