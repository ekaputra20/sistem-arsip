<?php
///////////////////////////////////////////////////////////////////////////
// set your upload directory name in here.
///////////////////////////////////////////////////////////////////////////
function myUploadDir(){
    $myUploadDir = "./upload/";
    return $myUploadDir;
}



///////////////////////////////////////////////////////////////////////////
// if you want to imposs file type rescriction then
// $check_file_extentions=1  or if you want to off this option then
// $check_file_extentions=0
///////////////////////////////////////////////////////////////////////////

$check_file_extentions = 1;

////////////////////////////////////////////////////////////////////////////
// set your allowed type in the array.
// examples: zip, pdf, psd and many more.
//
////////////////////////////////////////////////////////////////////////////
function allowedfiles()
                {
                        $allowed_file_extensions=array("png","jpg","gif","bmp");
                        return $allowed_file_extensions;
                }

///////////////////////////////////////////////////////////////////////////
// if you want to delete all the files in uploaded directory
// $clear_folder_before_upload = 1  or if you want to off this option then
// $clear_folder_before_upload = 0
///////////////////////////////////////////////////////////////////////////

$clear_folder_before_upload = 1;

function EmptyDir($dir) {

    $handle=opendir($dir);
    while (($file = readdir($handle))!==false) {
    @unlink($dir.'/'.$file);
    }
    closedir($handle);
}


?>