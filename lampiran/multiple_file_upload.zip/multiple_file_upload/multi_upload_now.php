<a href="multi_upload.php">Upload Again</a>
<?php
    require_once 'upload_config.php';
    
    if($clear_folder_before_upload){
        $mydirectory = myUploadDir();
        EmptyDir($mydirectory);
    }

    $uploaded_file_counter=0;
    $UploadLimit = $_POST['counter'];
    
    for($i=0;$i<=$UploadLimit;$i++){
        $file_tag='filename'.$i;
        $filename=$_FILES[$file_tag]['name'];

            if($filename!=null) {
            $rand=time();
            $str="$rand$filename";

            // set folder name in here.
            $filedir= myUploadDir();

            //change the string format.
            $string= $filedir.$str;
            $patterns[0] = "/ /";
            $patterns[1] = "/ /";
            $patterns[1] = "/ /";
            $replacements[1] = "_";
            $dirname=strtolower(preg_replace($patterns, $replacements, $string));
            //end of changing string format

            //checking the permitted file types
                            if($check_file_extentions)    {
                            $allowedExtensions = allowedfiles();
                                foreach ($_FILES as $file) {
                                                    if ($file['tmp_name'] > '') {
                                                      if (!in_array(end(explode(".",
                                                            strtolower($file['name']))),
                                                            $allowedExtensions)) {
                                                            $fileUploadPermission=0;
                                                      }
                                                      else
                                                      {
                                                          $fileUploadPermission=1;
                                                      }
                                                    }
                                                  }
                            }
                            else{
                                $fileUploadPermission=1;
                            }
            //end of checking the permitted file types
                if($fileUploadPermission){
                    if(move_uploaded_file($_FILES[$file_tag]['tmp_name'],$dirname)) {
                            echo "<p>";
                            echo "<img src='$dirname'>";
                            echo "</p>";
                            $uploaded_file_counter+=1;
                        }
                }
                
            }

    }
 
if($uploaded_file_counter==0){
    echo "<br /> <b style='font-weight:bold;color:red'>Opss! Please select an image file<b>";
}else{
    echo "<br /> <b>You request ".$i." image files to upload and ".$uploaded_file_counter." files uploaded sucessfully</b>";
}
?>